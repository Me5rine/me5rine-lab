<?php
// File: modules/subscription/functions/sync/subscription-sync-tipeee.php

if (!defined('ABSPATH')) exit;

/**
 * Fetch Tipeee subscriptions (paying members) for a Discord server
 * Uses Discord bot API to get members with specific Discord roles
 * Calls: /role-members?guild_id=...&role_id=...
 * 
 * @param array $channel Channel data
 * @param string $provider_slug Provider slug (default: 'tipeee')
 * @return array Array of subscription data or error array with '_error' key
 */
function admin_lab_fetch_tipeee_subscriptions($channel, $provider_slug = 'tipeee') {
    $provider = admin_lab_get_subscription_provider_by_slug($provider_slug);
    if (!$provider) {
        return ['_error' => "Provider '{$provider_slug}' not configured"];
    }

    $settings = !empty($provider['settings']) ? maybe_unserialize($provider['settings']) : [];
    $debug    = !empty($settings['debug_log']) || (defined('WP_DEBUG') && WP_DEBUG);

    $bot_api_url = rtrim($settings['bot_api_url'] ?? '', '/');
    $bot_api_key = $settings['bot_api_key'] ?? '';
    
    // Decrypt bot_api_key if encrypted
    if (!empty($bot_api_key) && function_exists('admin_lab_decrypt_data')) {
        $decrypted = admin_lab_decrypt_data($bot_api_key);
        // If decryption succeeded (returned value is different), use decrypted value
        if ($decrypted !== $bot_api_key) {
            $bot_api_key = $decrypted;
        }
    }

    // Safe logging: only in debug mode, and only hash/length, not the key itself
    if ($debug && function_exists('admin_lab_log_custom')) {
        admin_lab_log_custom("[TIPEEE SYNC] Using provider slug: {$provider_slug}", 'subscription-sync.log');
        admin_lab_log_custom("[TIPEEE SYNC] Bot API configured: url=" . ($bot_api_url ? 'yes' : 'no') . ", key=" . ($bot_api_key ? 'yes' : 'no'), 'subscription-sync.log');
        if ($bot_api_key) {
            // Safe: only log hash and length, never the actual key
            admin_lab_log_custom("[TIPEEE SYNC] bot_api_key_len=" . strlen($bot_api_key) . ", bot_api_key_sha=" . substr(hash('sha256', $bot_api_key), 0, 12), 'subscription-sync.log');
        }
    }

    if (!$bot_api_url || !$bot_api_key) {
        return ['_error' => 'Tipeee bot API not configured'];
    }

    $guild_id   = $channel['channel_identifier'];
    $guild_name = $channel['channel_name'];

    // Normalize provider_slug to base provider for level lookup
    // Levels are stored with base provider (tipeee), not specific (tipeee_me5rine)
    $base_provider_slug = 'tipeee';
    if (strpos($provider_slug, 'tipeee') === 0) {
        $base_provider_slug = 'tipeee';
    }

    // Get subscription levels for this provider that have discord_role_id configured
    $levels = admin_lab_get_subscription_levels_by_provider($base_provider_slug);
    
    if ($debug && function_exists('admin_lab_log_custom')) {
        admin_lab_log_custom("[TIPEEE SYNC] Found " . count($levels) . " level(s) for provider {$base_provider_slug}", 'subscription-sync.log');
    }
    
    $role_mappings = [];
    
    foreach ($levels as $level) {
        if (!empty($level['discord_role_id']) && !empty($level['level_slug'])) {
            $role_mappings[$level['discord_role_id']] = $level['level_slug'];
            if ($debug && function_exists('admin_lab_log_custom')) {
                admin_lab_log_custom("[TIPEEE SYNC] Mapped role {$level['discord_role_id']} -> level {$level['level_slug']}", 'subscription-sync.log');
            }
        }
    }
    
    // Fallback: also check provider settings for role mappings (backward compatibility)
    if (empty($role_mappings)) {
        $settings_role_mappings = $settings['role_mappings'] ?? [];
        if (is_array($settings_role_mappings) && !empty($settings_role_mappings)) {
            $role_mappings = $settings_role_mappings;
        }
    }
    
    if (empty($role_mappings)) {
        if ($debug && function_exists('admin_lab_log_custom')) {
            admin_lab_log_custom("[TIPEEE SYNC] No Discord role mappings configured for {$provider_slug}. Please configure discord_role_id in subscription types.", 'subscription-sync.log');
        }
        return ['_error' => 'No Discord role mappings configured for Tipeee. Please configure discord_role_id in subscription types or role mappings in provider settings.'];
    }

    $all_subscriptions = [];

    // Fetch members for each role
    foreach ($role_mappings as $role_id => $level_slug) {
        if (empty($role_id) || empty($level_slug)) {
            continue;
        }

        $url = add_query_arg([
            'guild_id' => $guild_id,
            'role_id' => $role_id,
        ], $bot_api_url . '/role-members');

        if ($debug && function_exists('admin_lab_log_custom')) {
            admin_lab_log_custom("[TIPEEE SYNC] Calling bot API for role {$role_id} -> level {$level_slug}: {$url}", 'subscription-sync.log');
        }

        $response = wp_remote_get($url, [
            'timeout' => 30,
            'headers' => [
                'x-admin-lab-key' => $bot_api_key,
                'accept' => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) {
            $msg = "Bot API error for role {$role_id}: " . $response->get_error_message();
            if ($debug && function_exists('admin_lab_log_custom')) {
                admin_lab_log_custom("[TIPEEE SYNC] ERROR: {$msg}", 'subscription-sync.log');
            }
            // Continue with other roles instead of failing completely
            continue;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($debug && function_exists('admin_lab_log_custom')) {
            admin_lab_log_custom("[TIPEEE SYNC] HTTP {$code} for role {$role_id}", 'subscription-sync.log');
            admin_lab_log_custom("[TIPEEE SYNC] Body (first 500): " . substr($body, 0, 500), 'subscription-sync.log');
        }

        if ($code !== 200) {
            if ($debug && function_exists('admin_lab_log_custom')) {
                admin_lab_log_custom("[TIPEEE SYNC] Bot API HTTP {$code} for role {$role_id}: {$body}", 'subscription-sync.log');
            }
            // Continue with other roles
            continue;
        }

        $data = json_decode($body, true);
        if (empty($data['members']) || !is_array($data['members'])) {
            if ($debug && function_exists('admin_lab_log_custom')) {
                admin_lab_log_custom("[TIPEEE SYNC] No members in response for role {$role_id}", 'subscription-sync.log');
            }
            continue;
        }

        // Map members to subscription format
        foreach ($data['members'] as $member) {
            $discord_user_id = $member['discord_user_id'] ?? $member['id'] ?? '';
            if (!$discord_user_id) continue;

            $started_at = null;
            if (!empty($member['joined_at'])) {
                $started_at = date('Y-m-d H:i:s', strtotime($member['joined_at']));
            } elseif (!empty($member['premium_since'])) {
                $started_at = date('Y-m-d H:i:s', strtotime($member['premium_since']));
            }

            $subscription_data = [
                'provider_slug' => $provider_slug, // Original provider slug (e.g., tipeee_me5rine) - will be normalized in admin_lab_save_subscription
                'external_user_id' => $discord_user_id,
                'external_username' => $member['username'] ?? $member['display_name'] ?? '',
                'external_subscription_id' => $discord_user_id . '_' . $guild_id . '_' . $level_slug,
                'level_slug' => $level_slug,
                'status' => 'active',
                'started_at' => $started_at,
                'expires_at' => null,
                'metadata' => json_encode([
                    'guild_id' => $guild_id,
                    'guild_name' => $data['guild_name'] ?? $guild_name,
                    'role_id' => $role_id,
                    'discord_user_id' => $discord_user_id,
                    'external_username' => $member['username'] ?? $member['display_name'] ?? '',
                    'subscription_type' => 'payant', // Tipeee members are always paid
                ]),
            ];
            
            if ($debug && function_exists('admin_lab_log_custom')) {
                admin_lab_log_custom("[TIPEEE SYNC] Created subscription data: provider_slug={$provider_slug}, level_slug={$level_slug}, user_id={$discord_user_id}", 'subscription-sync.log');
            }
            
            $all_subscriptions[] = $subscription_data;
        }

        if ($debug && function_exists('admin_lab_log_custom')) {
            admin_lab_log_custom("[TIPEEE SYNC] Mapped " . count($data['members']) . " member(s) for role {$role_id} -> level {$level_slug}", 'subscription-sync.log');
        }
    }

    if ($debug && function_exists('admin_lab_log_custom')) {
        admin_lab_log_custom("[TIPEEE SYNC] Total Tipeee members mapped: " . count($all_subscriptions) . " for provider {$provider_slug}", 'subscription-sync.log');
    }
    
    error_log("[TIPEEE SYNC] Returning " . count($all_subscriptions) . " subscription(s) for provider {$provider_slug}");

    return $all_subscriptions;
}

/**
 * Deactivate Tipeee members that no longer have the required Discord roles
 * Called after syncing Tipeee subscriptions to mark inactive those not in the current list
 * 
 * @param array $channel Channel data
 * @param array $active_subscription_ids Array of active subscription IDs
 * @return int Number of deactivated members
 */
function admin_lab_deactivate_inactive_tipeee_members($channel, $active_subscription_ids) {
    global $wpdb;
    $table = admin_lab_getTable('user_subscriptions');
    $guild_id = $channel['channel_identifier'];
    
    // Build WHERE clause to find Tipeee members for this guild
    // Use base provider_slug (tipeee) since subscriptions are stored with normalized provider_slug
    $where = $wpdb->prepare(
        "provider_slug = 'tipeee' AND JSON_UNQUOTE(JSON_EXTRACT(metadata, '$.guild_id')) = %s AND status = 'active'",
        $guild_id
    );
    
    // If we have active subscription IDs, exclude them from deactivation
    if (!empty($active_subscription_ids)) {
        $placeholders = implode(',', array_fill(0, count($active_subscription_ids), '%s'));
        $where .= $wpdb->prepare(" AND external_subscription_id NOT IN ({$placeholders})", ...$active_subscription_ids);
    }
    
    // Deactivate members not in the active list
    $deactivated = $wpdb->query(
        "UPDATE {$table} SET status = 'inactive', updated_at = NOW() WHERE {$where}"
    );
    
    if ($deactivated > 0) {
        if (function_exists('admin_lab_log_custom')) {
            admin_lab_log_custom("[TIPEEE SYNC] Deactivated {$deactivated} inactive member(s) for guild {$guild_id}", 'subscription-sync.log');
        }
        error_log("[TIPEEE SYNC] Deactivated {$deactivated} inactive member(s) for guild {$guild_id}");
    }
    
    return $deactivated;
}
