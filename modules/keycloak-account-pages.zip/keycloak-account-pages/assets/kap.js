(function () {
    async function api(path, options = {}) {
      const url = (AdminLabKAP.rest || '').replace(/\/$/, '') + path;
      const res = await fetch(url, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': AdminLabKAP.nonce,
          ...(options.headers || {})
        }
      });
      const data = await res.json().catch(() => null);
      if (!data || data.ok !== true) {
        const msg = data && data.error ? data.error : ('Erreur HTTP ' + res.status);
        throw new Error(msg);
      }
      return data.data;
    }
  
    function setMsg(key, text, ok) {
      const el = document.querySelector(`.me5rine-lab-form-message[data-msg="${key}"]`);
      if (!el) return;
      el.textContent = text;
      el.className = 'me5rine-lab-form-message ' + (ok ? 'me5rine-lab-form-message-success' : 'me5rine-lab-form-message-error');
    }
  
    async function renderConnections() {
      const wrap = document.getElementById('admin-lab-kap-connections');
      if (!wrap) return;
  
      try {
        const list = await api('/connections', { method: 'GET' });
        const rows = list.map(p => {
          const status = p.connected
            ? `<span class="me5rine-lab-form-badge me5rine-lab-form-badge-success">Connecté</span> <small>${p.external_username ? '— ' + p.external_username : ''}</small>`
            : `<span class="me5rine-lab-form-badge">Non connecté</span>`;
  
          const btn = p.connected
            ? `<button class="me5rine-lab-form-button me5rine-lab-form-button-danger" data-action="disconnect" data-provider="${p.provider_slug}">Déconnecter</button>`
            : `<button class="me5rine-lab-form-button" data-action="connect" data-provider="${p.provider_slug}">Connecter</button>`;
  
          return `<div class="me5rine-lab-form-row">
            <div class="me5rine-lab-form-col">
              <strong>${p.label}</strong><br>${status}
            </div>
            <div class="me5rine-lab-form-col me5rine-lab-form-col-right">${btn}</div>
          </div>`;
        }).join('');
  
        wrap.innerHTML = rows || '<p>Aucun provider configuré.</p>';
  
        wrap.querySelectorAll('button[data-action]').forEach(btn => {
          btn.addEventListener('click', async () => {
            const provider = btn.getAttribute('data-provider');
            const action = btn.getAttribute('data-action');
  
            btn.disabled = true;
            try {
              if (action === 'connect') {
                const out = await api('/connect', { method: 'POST', body: JSON.stringify({ provider_slug: provider }) });
                if (out.redirect) window.location.href = out.redirect;
              } else {
                await api('/disconnect', { method: 'POST', body: JSON.stringify({ provider_slug: provider }) });
                await renderConnections();
              }
            } catch (e) {
              alert(e.message);
            } finally {
              btn.disabled = false;
            }
          });
        });
  
      } catch (e) {
        wrap.innerHTML = `<p class="me5rine-lab-form-message me5rine-lab-form-message-error">${e.message}</p>`;
      }
    }
  
    async function loadProfileForm() {
      const form = document.getElementById('admin-lab-kap-profile-form');
      if (!form) return;
      try {
        const p = await api('/profile', { method: 'GET' });
        form.first_name.value = p.first_name || '';
        form.last_name.value = p.last_name || '';
        form.nickname.value = p.nickname || '';
      } catch (e) {
        setMsg('profile', e.message, false);
      }
  
      form.addEventListener('submit', async (ev) => {
        ev.preventDefault();
        setMsg('profile', 'Enregistrement…', true);
        try {
          await api('/profile', {
            method: 'POST',
            body: JSON.stringify({
              first_name: form.first_name.value,
              last_name: form.last_name.value,
              nickname: form.nickname.value,
            })
          });
          setMsg('profile', 'Profil mis à jour.', true);
        } catch (e) {
          setMsg('profile', e.message, false);
        }
      });
    }
  
    async function bindPasswordForm() {
      const form = document.getElementById('admin-lab-kap-password-form');
      if (!form) return;
  
      form.addEventListener('submit', async (ev) => {
        ev.preventDefault();
        setMsg('password', 'Changement…', true);
        try {
          await api('/password', {
            method: 'POST',
            body: JSON.stringify({
              password: form.password.value,
              password_confirm: form.password_confirm.value,
            })
          });
          form.password.value = '';
          form.password_confirm.value = '';
          setMsg('password', 'Mot de passe changé.', true);
        } catch (e) {
          setMsg('password', e.message, false);
        }
      });
    }
  
    document.addEventListener('DOMContentLoaded', function () {
      renderConnections();
      loadProfileForm();
      bindPasswordForm();
    });
  })();
