<?php
// File: modules/keycloak-account-pages/keycloak-account-pages.php

if (!defined('ABSPATH')) exit;

// Vérifie que le module est activé
$active_modules = get_option('admin_lab_active_modules', []);
if (!is_array($active_modules) || !in_array('keycloak_account_pages', $active_modules, true)) return;

// Définitions de constantes
define('ADMIN_LAB_KAP_VERSION', '1.0.0');
define('ADMIN_LAB_KAP_DIR', __DIR__);
define('ADMIN_LAB_KAP_URL', plugin_dir_url(__FILE__));

// Charger les classes
require_once ADMIN_LAB_KAP_DIR . '/includes/class-admin-lab-kap-db.php';
require_once ADMIN_LAB_KAP_DIR . '/includes/class-admin-lab-kap-keycloak.php';
require_once ADMIN_LAB_KAP_DIR . '/includes/class-admin-lab-kap-rest.php';
require_once ADMIN_LAB_KAP_DIR . '/includes/class-admin-lab-kap-shortcodes.php';
require_once ADMIN_LAB_KAP_DIR . '/includes/class-admin-lab-kap-admin.php';
require_once ADMIN_LAB_KAP_DIR . '/functions/admin-lab-kap-ultimate-member.php';

// Activation du module : création des tables (gérée par le système de DB du plugin)
add_action('init', function () {
    $active_modules = get_option('admin_lab_active_modules', []);
    if (in_array('keycloak_account_pages', $active_modules, true)) {

        // Options par défaut si elles n'existent pas
        $defaults = [
            'admin_lab_kap_kc_base_url'        => 'https://KEYCLOAK_DOMAIN',
            'admin_lab_kap_kc_realm'           => 'YOUR_REALM',
            'admin_lab_kap_kc_client_id'       => 'wordpress',
            'admin_lab_kap_kc_client_secret'   => '',
            'admin_lab_kap_kc_admin_client_id' => 'admin-cli',
            'admin_lab_kap_kc_admin_secret'    => '',
            'admin_lab_kap_kc_redirect_uri'    => home_url('/wp-json/admin-lab-kap/v1/keycloak/callback'),
            'admin_lab_kap_providers_json'     => wp_json_encode([
                'google'   => ['label' => 'Google',   'kc_alias' => 'google'],
                'discord'  => ['label' => 'Discord',  'kc_alias' => 'discord'],
                'facebook' => ['label' => 'Facebook', 'kc_alias' => 'facebook'],
                'twitch'   => ['label' => 'Twitch',   'kc_alias' => 'twitch'],
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            'admin_lab_kap_prevent_last_disconnect' => 1,
        ];
        foreach ($defaults as $k => $v) {
            if (get_option($k, null) === null) {
                add_option($k, $v);
            }
        }

        do_action('admin_lab_keycloak_account_pages_module_activated');
    }
});

// Enregistrement des assets
add_action('init', function () {
    wp_register_script('admin-lab-kap-js', ADMIN_LAB_KAP_URL . 'assets/kap.js', ['wp-api-fetch'], ADMIN_LAB_KAP_VERSION, true);
    wp_register_style('admin-lab-kap-css', ADMIN_LAB_KAP_URL . 'assets/kap.css', [], ADMIN_LAB_KAP_VERSION);
});

// Initialisation des classes
add_action('plugins_loaded', function () {
    $active_modules = get_option('admin_lab_active_modules', []);
    if (in_array('keycloak_account_pages', $active_modules, true)) {
        Admin_Lab_KAP_Admin::init();
        Admin_Lab_KAP_Rest::init();
        
        // Intégration Ultimate Member
        if (class_exists('UM')) {
            Admin_Lab_KAP_Ultimate_Member::init();
        }
    }
});

// Enregistrement des shortcodes sur init (comme les autres modules)
add_action('init', function () {
    $active_modules = get_option('admin_lab_active_modules', []);
    if (in_array('keycloak_account_pages', $active_modules, true)) {
        Admin_Lab_KAP_Shortcodes::init();
    }
}, 10);

// Désactivation du module
add_action('admin_lab_keycloak_account_pages_module_desactivated', function () {
    // Actions de nettoyage si nécessaire
});
