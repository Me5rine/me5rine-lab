<?php
// File: modules/keycloak-account-pages/functions/admin-lab-kap-ultimate-member.php

if (!defined('ABSPATH')) exit;

class Admin_Lab_KAP_Ultimate_Member {

  public static function init(): void {
    // Ajouter des onglets dans le profil Ultimate Member
    add_filter('um_profile_tabs', [__CLASS__, 'add_profile_tabs'], 1000);
    add_action('um_profile_content_connexions_default', [__CLASS__, 'render_connections_tab']);
    add_action('um_profile_content_compte_default', [__CLASS__, 'render_account_settings_tab']);
    
    // Fallback : si Ultimate Member traite le contenu comme du texte, traiter les shortcodes
    add_filter('um_profile_tab_content_connexions', [__CLASS__, 'process_shortcode_in_content'], 10, 2);
    add_filter('um_profile_tab_content_compte', [__CLASS__, 'process_shortcode_in_content'], 10, 2);
  }
  
  /**
   * Traite les shortcodes dans le contenu des onglets (si Ultimate Member les passe comme texte)
   */
  public static function process_shortcode_in_content($content, $tab) {
    // Si le contenu contient notre shortcode en texte brut, le traiter
    if (is_string($content)) {
      if (strpos($content, '[admin_lab_kap_connections]') !== false) {
        $content = str_replace('[admin_lab_kap_connections]', admin_lab_kap_render_connections(), $content);
      }
      if (strpos($content, '[admin_lab_kap_account_settings]') !== false) {
        $content = str_replace('[admin_lab_kap_account_settings]', admin_lab_kap_render_account_settings(), $content);
      }
      // Traiter aussi via do_shortcode au cas où
      $content = do_shortcode($content);
    }
    return $content;
  }

  /**
   * Ajoute les onglets dans le profil Ultimate Member
   */
  public static function add_profile_tabs($tabs) {
    if (!is_array($tabs)) {
      $tabs = [];
    }

    $tabs['connexions'] = [
      'name' => 'Connexions',
      'icon' => 'um-faicon-link',
    ];

    $tabs['compte'] = [
      'name' => 'Mon compte',
      'icon' => 'um-faicon-cog',
    ];

    return $tabs;
  }

  /**
   * Affiche le contenu de l'onglet Connexions
   * Appelle directement la fonction de rendu (plus fiable que do_shortcode dans Ultimate Member)
   */
  public static function render_connections_tab($args) {
    // Debug : vérifier que la fonction est appelée
    // error_log('KAP: render_connections_tab called');
    
    if (!is_user_logged_in()) {
      return;
    }
    
    // S'assurer que le fichier shortcodes est chargé
    if (!function_exists('admin_lab_kap_render_connections')) {
      // Le fichier devrait être chargé, mais au cas où...
      if (defined('ADMIN_LAB_KAP_DIR') && file_exists(ADMIN_LAB_KAP_DIR . '/includes/class-admin-lab-kap-shortcodes.php')) {
        require_once ADMIN_LAB_KAP_DIR . '/includes/class-admin-lab-kap-shortcodes.php';
      }
    }
    
    // Appelle directement la fonction de rendu (plus fiable)
    if (function_exists('admin_lab_kap_render_connections')) {
      echo admin_lab_kap_render_connections();
      return;
    }
    
    if (class_exists('Admin_Lab_KAP_Shortcodes')) {
      // Fallback vers la méthode de classe
      echo Admin_Lab_KAP_Shortcodes::connections();
      return;
    }
    
    // Si rien ne fonctionne, afficher un message d'erreur
    echo '<p>Erreur : Le module Keycloak Account Pages n\'est pas correctement chargé. Fonction admin_lab_kap_render_connections non trouvée.</p>';
  }

  /**
   * Affiche le contenu de l'onglet Mon compte
   * Appelle directement la fonction de rendu (plus fiable que do_shortcode dans Ultimate Member)
   */
  public static function render_account_settings_tab($args) {
    // Debug : vérifier que la fonction est appelée
    // error_log('KAP: render_account_settings_tab called');
    
    if (!is_user_logged_in()) {
      return;
    }
    
    // S'assurer que le fichier shortcodes est chargé
    if (!function_exists('admin_lab_kap_render_account_settings')) {
      // Le fichier devrait être chargé, mais au cas où...
      if (defined('ADMIN_LAB_KAP_DIR') && file_exists(ADMIN_LAB_KAP_DIR . '/includes/class-admin-lab-kap-shortcodes.php')) {
        require_once ADMIN_LAB_KAP_DIR . '/includes/class-admin-lab-kap-shortcodes.php';
      }
    }
    
    // Appelle directement la fonction de rendu (plus fiable)
    if (function_exists('admin_lab_kap_render_account_settings')) {
      echo admin_lab_kap_render_account_settings();
      return;
    }
    
    if (class_exists('Admin_Lab_KAP_Shortcodes')) {
      // Fallback vers la méthode de classe
      echo Admin_Lab_KAP_Shortcodes::account_settings();
      return;
    }
    
    // Si rien ne fonctionne, afficher un message d'erreur
    echo '<p>Erreur : Le module Keycloak Account Pages n\'est pas correctement chargé. Fonction admin_lab_kap_render_account_settings non trouvée.</p>';
  }
}

