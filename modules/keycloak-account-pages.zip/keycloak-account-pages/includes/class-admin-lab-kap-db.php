<?php
// File: modules/keycloak-account-pages/includes/class-admin-lab-kap-db.php

if (!defined('ABSPATH')) exit;

class Admin_Lab_KAP_DB {

  public static function table(): string {
    return admin_lab_getTable('keycloak_accounts');
  }

  /**
   * Crée la table keycloak_accounts si elle n'existe pas
   */
  public static function create_table(): void {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = self::table();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      user_id BIGINT UNSIGNED NOT NULL,
      provider_slug VARCHAR(50) NOT NULL,
      external_user_id VARCHAR(255) NOT NULL DEFAULT '',
      external_username VARCHAR(255) DEFAULT NULL,
      keycloak_identity_id VARCHAR(255) DEFAULT NULL,
      is_active TINYINT(1) NOT NULL DEFAULT 1,
      last_sync_at DATETIME DEFAULT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      KEY user_id (user_id),
      KEY provider_slug (provider_slug),
      KEY external_user_id (external_user_id),
      KEY keycloak_identity_id (keycloak_identity_id)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
  }

  public static function get_kc_identity_id_for_user(int $user_id, bool $only_active = true): string {
    global $wpdb;
    $table = self::table();

    if ($only_active) {
      $sql = "SELECT keycloak_identity_id FROM {$table}
              WHERE user_id = %d AND is_active = 1 AND keycloak_identity_id <> ''
              ORDER BY updated_at DESC, id DESC LIMIT 1";
    } else {
      $sql = "SELECT keycloak_identity_id FROM {$table}
              WHERE user_id = %d AND keycloak_identity_id <> ''
              ORDER BY updated_at DESC, id DESC LIMIT 1";
    }

    $val = $wpdb->get_var($wpdb->prepare($sql, $user_id));
    return $val ? (string)$val : '';
  }

  public static function get_active_connections(int $user_id): array {
    global $wpdb;
    $table = self::table();
    $rows = $wpdb->get_results($wpdb->prepare(
      "SELECT * FROM {$table} WHERE user_id = %d AND is_active = 1",
      $user_id
    ), ARRAY_A);
    return is_array($rows) ? $rows : [];
  }

  public static function get_connection(int $user_id, string $provider_slug): ?array {
    global $wpdb;
    $table = self::table();
    $row = $wpdb->get_row($wpdb->prepare(
      "SELECT * FROM {$table} WHERE user_id = %d AND provider_slug = %s ORDER BY id DESC LIMIT 1",
      $user_id, $provider_slug
    ), ARRAY_A);
    return $row ?: null;
  }

  public static function upsert_connection(array $data): int {
    global $wpdb;
    $table = self::table();

    $defaults = [
      'user_id' => 0,
      'provider_slug' => '',
      'external_user_id' => '',
      'external_username' => '',
      'keycloak_identity_id' => '',
      'is_active' => 1,
      'last_sync_at' => current_time('mysql'),
      'updated_at' => current_time('mysql'),
      'created_at' => current_time('mysql'),
    ];
    $data = array_merge($defaults, $data);

    $existing = self::get_connection((int)$data['user_id'], (string)$data['provider_slug']);

    if ($existing) {
      $wpdb->update(
        $table,
        [
          'external_user_id'      => $data['external_user_id'],
          'external_username'     => $data['external_username'],
          'keycloak_identity_id'  => $data['keycloak_identity_id'] ?: $existing['keycloak_identity_id'],
          'is_active'             => (int)$data['is_active'],
          'last_sync_at'          => $data['last_sync_at'],
          'updated_at'            => current_time('mysql'),
        ],
        ['id' => (int)$existing['id']],
        ['%s','%s','%s','%d','%s','%s'],
        ['%d']
      );
      return (int)$existing['id'];
    }

    $wpdb->insert(
      $table,
      [
        'user_id'              => (int)$data['user_id'],
        'provider_slug'        => (string)$data['provider_slug'],
        'external_user_id'     => (string)$data['external_user_id'],
        'external_username'    => (string)$data['external_username'],
        'keycloak_identity_id' => (string)$data['keycloak_identity_id'],
        'is_active'            => (int)$data['is_active'],
        'last_sync_at'         => $data['last_sync_at'],
        'created_at'           => $data['created_at'],
        'updated_at'           => $data['updated_at'],
      ],
      ['%d','%s','%s','%s','%s','%d','%s','%s','%s']
    );
    return (int)$wpdb->insert_id;
  }

  public static function deactivate_connection(int $user_id, string $provider_slug): void {
    global $wpdb;
    $table = self::table();
    $wpdb->update(
      $table,
      ['is_active' => 0, 'updated_at' => current_time('mysql')],
      ['user_id' => $user_id, 'provider_slug' => $provider_slug],
      ['%d','%s'],
      ['%d','%s']
    );
  }
}

