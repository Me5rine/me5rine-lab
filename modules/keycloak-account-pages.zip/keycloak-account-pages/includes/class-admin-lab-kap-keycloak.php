<?php
// File: modules/keycloak-account-pages/includes/class-admin-lab-kap-keycloak.php

if (!defined('ABSPATH')) exit;

class Admin_Lab_KAP_Keycloak {

  public static function opt(string $key, $default = '') {
    $v = get_option('admin_lab_kap_' . $key, null);
    return $v === null ? $default : $v;
  }

  public static function get_providers(): array {
    $json = (string) self::opt('providers_json', '{}');
    $arr = json_decode($json, true);
    if (!is_array($arr)) $arr = [];
    return apply_filters('admin_lab_kap_providers', $arr);
  }

  /**
   * Récupère le Keycloak user ID depuis la table keycloak_accounts
   * On le prend depuis une connexion active si possible, sinon la dernière connue.
   */
  public static function get_kc_user_id_for_wp_user(int $user_id): string {
    $kc = Admin_Lab_KAP_DB::get_kc_identity_id_for_user($user_id, true);
    if (!$kc) {
      $kc = Admin_Lab_KAP_DB::get_kc_identity_id_for_user($user_id, false);
    }
    return (string) apply_filters('admin_lab_kap_kc_user_id', $kc, $user_id);
  }

  public static function base_realm_url(): string {
    $base = rtrim((string) self::opt('kc_base_url'), '/');
    $realm = rawurlencode((string) self::opt('kc_realm'));
    return "{$base}/realms/{$realm}";
  }

  public static function admin_url(): string {
    $base = rtrim((string) self::opt('kc_base_url'), '/');
    $realm = rawurlencode((string) self::opt('kc_realm'));
    return "{$base}/admin/realms/{$realm}";
  }

  public static function get_admin_token(): string {
    $cached = get_transient('admin_lab_kap_kc_admin_token');
    if ($cached) return (string)$cached;

    $token_url = self::base_realm_url() . '/protocol/openid-connect/token';

    $client_id = (string) self::opt('kc_admin_client_id');
    $client_secret = (string) self::opt('kc_admin_secret');

    $resp = wp_remote_post($token_url, [
      'timeout' => 15,
      'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
      'body'    => http_build_query([
        'grant_type' => 'client_credentials',
        'client_id' => $client_id,
        'client_secret' => $client_secret,
      ], '', '&'),
    ]);

    if (is_wp_error($resp)) {
      throw new Exception('Keycloak token error: ' . $resp->get_error_message());
    }

    $code = wp_remote_retrieve_response_code($resp);
    $body = json_decode(wp_remote_retrieve_body($resp), true);

    if ($code < 200 || $code >= 300 || !is_array($body) || empty($body['access_token'])) {
      throw new Exception('Keycloak token error: HTTP ' . $code);
    }

    $ttl = !empty($body['expires_in']) ? max(30, (int)$body['expires_in'] - 30) : 240;
    set_transient('admin_lab_kap_kc_admin_token', $body['access_token'], $ttl);

    return (string)$body['access_token'];
  }

  public static function admin_request(string $method, string $path, array $jsonBody = null): array {
    $token = self::get_admin_token();
    $url = self::admin_url() . $path;

    $args = [
      'timeout' => 15,
      'method'  => $method,
      'headers' => [
        'Authorization' => 'Bearer ' . $token,
        'Content-Type'  => 'application/json',
      ],
    ];

    if ($jsonBody !== null) {
      $args['body'] = wp_json_encode($jsonBody);
    }

    $resp = wp_remote_request($url, $args);
    if (is_wp_error($resp)) {
      throw new Exception('Keycloak admin request error: ' . $resp->get_error_message());
    }

    $code = wp_remote_retrieve_response_code($resp);
    $raw  = wp_remote_retrieve_body($resp);

    $data = null;
    if ($raw !== '') {
      $parsed = json_decode($raw, true);
      $data = is_array($parsed) ? $parsed : $raw;
    }

    return ['code' => $code, 'data' => $data];
  }

  /**
   * Keycloak broker link endpoint
   * Compatible avec Keycloak 26.2.4
   */
  public static function build_link_url(string $provider_alias, string $state): string {
    $client_id = rawurlencode((string) self::opt('kc_client_id'));
    $redirect  = rawurlencode((string) self::opt('kc_redirect_uri'));
    $alias     = rawurlencode($provider_alias);

    return self::base_realm_url() . "/broker/{$alias}/link?client_id={$client_id}&redirect_uri={$redirect}&state=" . rawurlencode($state);
  }

  public static function unlink_provider(string $kc_user_id, string $provider_alias): void {
    $kc_user_id = rawurlencode($kc_user_id);
    $provider_alias = rawurlencode($provider_alias);

    $res = self::admin_request('DELETE', "/users/{$kc_user_id}/federated-identity/{$provider_alias}");
    if ($res['code'] !== 204 && ($res['code'] < 200 || $res['code'] >= 300)) {
      throw new Exception('Keycloak unlink failed (HTTP ' . $res['code'] . ')');
    }
  }

  public static function update_user(string $kc_user_id, array $payload): void {
    $kc_user_id = rawurlencode($kc_user_id);
    $res = self::admin_request('PUT', "/users/{$kc_user_id}", $payload);
    if ($res['code'] < 200 || $res['code'] >= 300) {
      throw new Exception('Keycloak update user failed (HTTP ' . $res['code'] . ')');
    }
  }

  public static function reset_password(string $kc_user_id, string $new_password, bool $temporary = false): void {
    $kc_user_id = rawurlencode($kc_user_id);
    $res = self::admin_request('PUT', "/users/{$kc_user_id}/reset-password", [
      'type' => 'password',
      'temporary' => $temporary,
      'value' => $new_password,
    ]);
    if ($res['code'] < 200 || $res['code'] >= 300) {
      throw new Exception('Keycloak reset password failed (HTTP ' . $res['code'] . ')');
    }
  }

  /**
   * Récupère les identités fédérées (remplit external_user_id / external_username)
   * GET /users/{id}/federated-identity
   * Compatible avec Keycloak 26.2.4
   */
  public static function get_federated_identities(string $kc_user_id): array {
    $kc_user_id = rawurlencode($kc_user_id);
    $res = self::admin_request('GET', "/users/{$kc_user_id}/federated-identity");
    if ($res['code'] < 200 || $res['code'] >= 300 || !is_array($res['data'])) {
      throw new Exception('Keycloak federated identities failed (HTTP ' . $res['code'] . ')');
    }
    return $res['data'];
  }
}

