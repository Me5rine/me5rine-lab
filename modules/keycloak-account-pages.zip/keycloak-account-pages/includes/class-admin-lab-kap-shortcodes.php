<?php
// File: modules/keycloak-account-pages/includes/class-admin-lab-kap-shortcodes.php

if (!defined('ABSPATH')) exit;

class Admin_Lab_KAP_Shortcodes {

  public static function init(): void {
    // Enregistrer les shortcodes avec des noms de fonctions (pattern standard WordPress)
    add_shortcode('admin_lab_kap_connections', 'admin_lab_kap_shortcode_connections');
    add_shortcode('admin_lab_kap_account_settings', 'admin_lab_kap_shortcode_account_settings');
    
    add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue']);
  }

  public static function enqueue(): void {
    if (!is_user_logged_in()) return;

    // Charger sur les pages de profil Ultimate Member ou sur n'importe quelle page si l'utilisateur est connecté
    $should_load = true;
    if (function_exists('um_is_core_page')) {
      // Charger sur les pages de profil Ultimate Member
      $should_load = um_is_core_page('user');
    }

    if (!$should_load) {
      // Vérifier si un shortcode est présent sur la page
      global $post;
      if ($post && (
        has_shortcode($post->post_content, 'admin_lab_kap_connections') ||
        has_shortcode($post->post_content, 'admin_lab_kap_account_settings')
      )) {
        $should_load = true;
      }
    }

    if (!$should_load) return;

    wp_enqueue_style('admin-lab-kap-css');
    wp_enqueue_script('admin-lab-kap-js');

    wp_localize_script('admin-lab-kap-js', 'AdminLabKAP', [
      'rest' => esc_url_raw(rest_url('admin-lab-kap/v1')),
      'nonce' => wp_create_nonce('wp_rest'),
    ]);
  }

  // Méthodes statiques conservées pour compatibilité avec Ultimate Member
  public static function connections(): string {
    return admin_lab_kap_render_connections();
  }

  public static function account_settings(): string {
    return admin_lab_kap_render_account_settings();
  }
}

/**
 * Callback pour le shortcode admin_lab_kap_connections
 */
function admin_lab_kap_shortcode_connections($atts = [], $content = null) {
  return admin_lab_kap_render_connections();
}

/**
 * Callback pour le shortcode admin_lab_kap_account_settings
 */
function admin_lab_kap_shortcode_account_settings($atts = [], $content = null) {
  return admin_lab_kap_render_account_settings();
}

/**
 * Fonction de rendu pour les connexions (pattern similaire à poke_hub_render_user_profile)
 */
function admin_lab_kap_render_connections() {
  if (!is_user_logged_in()) {
    return '<p>Vous devez être connecté.</p>';
  }

  // S'assurer que les assets sont chargés
  Admin_Lab_KAP_Shortcodes::enqueue();

  ob_start(); ?>
  <div class="me5rine-lab-form-wrap">
    <h2>Connexions</h2>
    <div id="admin-lab-kap-connections" class="me5rine-lab-form-card">
      <p>Chargement…</p>
    </div>
  </div>
  <?php
  return (string)ob_get_clean();
}

/**
 * Fonction de rendu pour les paramètres du compte (pattern similaire à poke_hub_render_user_profile)
 */
function admin_lab_kap_render_account_settings() {
  if (!is_user_logged_in()) {
    return '<p>Vous devez être connecté.</p>';
  }

  // S'assurer que les assets sont chargés
  Admin_Lab_KAP_Shortcodes::enqueue();

  ob_start(); ?>
  <div class="me5rine-lab-form-wrap">
    <h2>Mon compte</h2>

    <div class="me5rine-lab-form-card">
      <h3>Profil</h3>
      <form id="admin-lab-kap-profile-form" class="me5rine-lab-form">
        <div class="me5rine-lab-form-field">
          <label>Prénom<br>
            <input type="text" name="first_name" class="me5rine-lab-form-input" required>
          </label>
        </div>
        <div class="me5rine-lab-form-field">
          <label>Nom<br>
            <input type="text" name="last_name" class="me5rine-lab-form-input" required>
          </label>
        </div>
        <div class="me5rine-lab-form-field">
          <label>Pseudo<br>
            <input type="text" name="nickname" class="me5rine-lab-form-input" required>
          </label>
        </div>
        <div class="me5rine-lab-form-field">
          <button type="submit" class="me5rine-lab-form-button">Enregistrer</button>
        </div>
        <div class="me5rine-lab-form-message" data-msg="profile"></div>
      </form>
    </div>

    <div class="me5rine-lab-form-card">
      <h3>Mot de passe</h3>
      <form id="admin-lab-kap-password-form" class="me5rine-lab-form">
        <div class="me5rine-lab-form-field">
          <label>Nouveau mot de passe<br>
            <input type="password" name="password" class="me5rine-lab-form-input" required>
          </label>
        </div>
        <div class="me5rine-lab-form-field">
          <label>Confirmer<br>
            <input type="password" name="password_confirm" class="me5rine-lab-form-input" required>
          </label>
        </div>
        <div class="me5rine-lab-form-field">
          <button type="submit" class="me5rine-lab-form-button">Changer le mot de passe</button>
        </div>
        <div class="me5rine-lab-form-message" data-msg="password"></div>
      </form>
    </div>
  </div>
  <?php
  return (string)ob_get_clean();
}

