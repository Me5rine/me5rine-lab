<?php
// File: modules/keycloak-account-pages/includes/class-admin-lab-kap-rest.php

if (!defined('ABSPATH')) exit;

class Admin_Lab_KAP_Rest {

  public static function init(): void {
    add_action('rest_api_init', [__CLASS__, 'routes']);
  }

  public static function routes(): void {
    register_rest_route('admin-lab-kap/v1', '/connections', [
      'methods' => 'GET',
      'permission_callback' => [__CLASS__, 'must_be_logged_in'],
      'callback' => [__CLASS__, 'get_connections'],
    ]);

    register_rest_route('admin-lab-kap/v1', '/connect', [
      'methods' => 'POST',
      'permission_callback' => [__CLASS__, 'must_be_logged_in'],
      'callback' => [__CLASS__, 'connect_provider'],
    ]);

    register_rest_route('admin-lab-kap/v1', '/disconnect', [
      'methods' => 'POST',
      'permission_callback' => [__CLASS__, 'must_be_logged_in'],
      'callback' => [__CLASS__, 'disconnect_provider'],
    ]);

    register_rest_route('admin-lab-kap/v1', '/profile', [
      'methods' => 'GET',
      'permission_callback' => [__CLASS__, 'must_be_logged_in'],
      'callback' => [__CLASS__, 'get_profile'],
    ]);

    register_rest_route('admin-lab-kap/v1', '/profile', [
      'methods' => 'POST',
      'permission_callback' => [__CLASS__, 'must_be_logged_in'],
      'callback' => [__CLASS__, 'update_profile'],
    ]);

    register_rest_route('admin-lab-kap/v1', '/password', [
      'methods' => 'POST',
      'permission_callback' => [__CLASS__, 'must_be_logged_in'],
      'callback' => [__CLASS__, 'update_password'],
    ]);

    // Callback Keycloak broker link
    register_rest_route('admin-lab-kap/v1', '/keycloak/callback', [
      'methods' => 'GET',
      'permission_callback' => '__return_true',
      'callback' => [__CLASS__, 'keycloak_callback'],
    ]);
  }

  public static function must_be_logged_in(): bool {
    return is_user_logged_in();
  }

  private static function json_ok($data) {
    return new WP_REST_Response(['ok' => true, 'data' => $data], 200);
  }

  private static function json_err(string $message, int $status = 400) {
    return new WP_REST_Response(['ok' => false, 'error' => $message], $status);
  }

  public static function get_connections(WP_REST_Request $req) {
    $user_id = get_current_user_id();
    $providers = Admin_Lab_KAP_Keycloak::get_providers();
    $active = Admin_Lab_KAP_DB::get_active_connections($user_id);

    $map = [];
    foreach ($active as $row) {
      $map[$row['provider_slug']] = $row;
    }

    $out = [];
    foreach ($providers as $slug => $cfg) {
      $row = $map[$slug] ?? null;
      $out[] = [
        'provider_slug' => $slug,
        'label' => $cfg['label'] ?? $slug,
        'kc_alias' => $cfg['kc_alias'] ?? $slug,
        'connected' => $row ? true : false,
        'external_username' => $row['external_username'] ?? null,
        'last_sync_at' => $row['last_sync_at'] ?? null,
      ];
    }

    return self::json_ok($out);
  }

  public static function connect_provider(WP_REST_Request $req) {
    $user_id = get_current_user_id();
    $provider = sanitize_key((string)$req->get_param('provider_slug'));
    if (!$provider) return self::json_err('provider_slug manquant');

    $providers = Admin_Lab_KAP_Keycloak::get_providers();
    if (empty($providers[$provider])) return self::json_err('Provider inconnu');

    $kc_alias = $providers[$provider]['kc_alias'] ?? $provider;

    // state signé : user_id + provider + nonce + timestamp
    $payload = [
      'u' => $user_id,
      'p' => $provider,
      't' => time(),
      'n' => wp_create_nonce('admin_lab_kap_state_' . $user_id),
    ];
    $state_raw = wp_json_encode($payload);
    $sig = hash_hmac('sha256', $state_raw, wp_salt('auth'));
    $state = base64_encode($state_raw) . '.' . $sig;

    $url = Admin_Lab_KAP_Keycloak::build_link_url($kc_alias, $state);

    return self::json_ok(['redirect' => $url]);
  }

  public static function disconnect_provider(WP_REST_Request $req) {
    $user_id = get_current_user_id();
    $provider = sanitize_key((string)$req->get_param('provider_slug'));
    if (!$provider) return self::json_err('provider_slug manquant');

    $providers = Admin_Lab_KAP_Keycloak::get_providers();
    if (empty($providers[$provider])) return self::json_err('Provider inconnu');

    $prevent_last = (int)Admin_Lab_KAP_Keycloak::opt('prevent_last_disconnect', 1) === 1;

    if ($prevent_last) {
      $active = Admin_Lab_KAP_DB::get_active_connections($user_id);
      $count = 0;
      foreach ($active as $row) {
        if (!empty($row['provider_slug'])) $count++;
      }
      if ($count <= 1) {
        return self::json_err("Impossible de déconnecter le dernier provider (risque de blocage).", 409);
      }
    }

    $kc_user_id = Admin_Lab_KAP_Keycloak::get_kc_user_id_for_wp_user($user_id);
    if (!$kc_user_id) return self::json_err("keycloak_user_id introuvable pour cet utilisateur.");

    $kc_alias = $providers[$provider]['kc_alias'] ?? $provider;

    try {
      Admin_Lab_KAP_Keycloak::unlink_provider($kc_user_id, $kc_alias);
      Admin_Lab_KAP_DB::deactivate_connection($user_id, $provider);
      return self::json_ok(['provider_slug' => $provider, 'disconnected' => true]);
    } catch (Exception $e) {
      return self::json_err($e->getMessage(), 500);
    }
  }

  public static function get_profile(WP_REST_Request $req) {
    $user = wp_get_current_user();
    return self::json_ok([
      'first_name' => $user->first_name,
      'last_name'  => $user->last_name,
      'nickname'   => get_user_meta($user->ID, 'nickname', true) ?: $user->display_name,
      'display_name' => $user->display_name,
      'user_email' => $user->user_email,
    ]);
  }

  public static function update_profile(WP_REST_Request $req) {
    $user_id = get_current_user_id();
    $user = get_userdata($user_id);

    $first = sanitize_text_field((string)$req->get_param('first_name'));
    $last  = sanitize_text_field((string)$req->get_param('last_name'));
    $nick  = sanitize_text_field((string)$req->get_param('nickname'));

    // Update WP
    wp_update_user([
      'ID' => $user_id,
      'first_name' => $first,
      'last_name'  => $last,
      'display_name' => $nick ?: ($user->display_name ?: $user->user_login),
    ]);
    if ($nick) update_user_meta($user_id, 'nickname', $nick);

    // Update Keycloak (si possible)
    $kc_user_id = Admin_Lab_KAP_Keycloak::get_kc_user_id_for_wp_user($user_id);
    if ($kc_user_id) {
      try {
        Admin_Lab_KAP_Keycloak::update_user($kc_user_id, [
          'firstName' => $first,
          'lastName'  => $last,
          'attributes' => [
            'nickname' => [$nick],
          ],
        ]);
      } catch (Exception $e) {
        // WP est à jour, Keycloak a échoué -> on remonte l'info
        return self::json_err("WP ok, Keycloak erreur: " . $e->getMessage(), 502);
      }
    }

    return self::json_ok(['updated' => true]);
  }

  public static function update_password(WP_REST_Request $req) {
    $user_id = get_current_user_id();
    $pass1 = (string)$req->get_param('password');
    $pass2 = (string)$req->get_param('password_confirm');

    if (strlen($pass1) < 8) return self::json_err("Mot de passe trop court (min 8).");
    if ($pass1 !== $pass2) return self::json_err("Les mots de passe ne correspondent pas.");

    $kc_user_id = Admin_Lab_KAP_Keycloak::get_kc_user_id_for_wp_user($user_id);
    if (!$kc_user_id) return self::json_err("keycloak_user_id introuvable pour cet utilisateur.");

    try {
      Admin_Lab_KAP_Keycloak::reset_password($kc_user_id, $pass1, false);
      return self::json_ok(['password_changed' => true]);
    } catch (Exception $e) {
      return self::json_err($e->getMessage(), 500);
    }
  }

  /**
   * Callback après linking Keycloak.
   * Keycloak renvoie state (+ potentiellement d'autres params).
   * Ici, on marque la connexion active dans la table.
   */
  public static function keycloak_callback(WP_REST_Request $req) {
    $state = (string)$req->get_param('state');
    if (!$state || strpos($state, '.') === false) {
      return new WP_REST_Response('Invalid state', 400);
    }

    [$b64, $sig] = explode('.', $state, 2);
    $raw = base64_decode($b64, true);
    if (!$raw) return new WP_REST_Response('Invalid state payload', 400);

    $expected = hash_hmac('sha256', $raw, wp_salt('auth'));
    if (!hash_equals($expected, $sig)) {
      return new WP_REST_Response('Invalid state signature', 403);
    }

    $payload = json_decode($raw, true);
    if (!is_array($payload) || empty($payload['u']) || empty($payload['p']) || empty($payload['n'])) {
      return new WP_REST_Response('Invalid state data', 400);
    }

    $user_id = (int)$payload['u'];
    $provider = sanitize_key((string)$payload['p']);
    if (!wp_verify_nonce((string)$payload['n'], 'admin_lab_kap_state_' . $user_id)) {
      return new WP_REST_Response('Invalid nonce', 403);
    }

    // On essaie de récupérer le kc_user_id depuis la table (déjà lié via un provider existant)
    $kc_user_id = Admin_Lab_KAP_Keycloak::get_kc_user_id_for_wp_user($user_id);

    // On active au minimum la ligne provider
    Admin_Lab_KAP_DB::upsert_connection([
      'user_id' => $user_id,
      'provider_slug' => $provider,
      'keycloak_identity_id' => $kc_user_id, // peut être vide si user tout neuf sans autre lien
      'is_active' => 1,
      'last_sync_at' => current_time('mysql'),
    ]);

    // Si on a le kc_user_id, on pull toutes les identités fédérées et on remplit external_user_id/username
    if ($kc_user_id) {
      try {
        $providers = Admin_Lab_KAP_Keycloak::get_providers();
        $fed = Admin_Lab_KAP_Keycloak::get_federated_identities($kc_user_id);

        // fed items contiennent souvent : identityProvider, userId, userName
        foreach ($fed as $item) {
          if (!is_array($item)) continue;

          $alias = (string)($item['identityProvider'] ?? '');
          $extId = (string)($item['userId'] ?? '');
          $extName = (string)($item['userName'] ?? '');

          if (!$alias) continue;

          // retrouver provider_slug correspondant à cet alias
          $provider_slug = null;
          foreach ($providers as $slug => $cfg) {
            $cfg_alias = $cfg['kc_alias'] ?? $slug;
            if ($cfg_alias === $alias) {
              $provider_slug = $slug;
              break;
            }
          }
          if (!$provider_slug) {
            // provider non déclaré côté WP : on ignore
            continue;
          }

          Admin_Lab_KAP_DB::upsert_connection([
            'user_id' => $user_id,
            'provider_slug' => $provider_slug,
            'external_user_id' => $extId,
            'external_username' => $extName,
            'keycloak_identity_id' => $kc_user_id,
            'is_active' => 1,
            'last_sync_at' => current_time('mysql'),
          ]);
        }
      } catch (Exception $e) {
        // On n'empêche pas la redirection
      }
    }
      
    // Redirige vers la page de profil Ultimate Member ou la page par défaut
    $redirect_url = home_url('/');
    if (function_exists('um_get_core_page') && function_exists('um_user_profile_url')) {
      $profile_url = um_user_profile_url();
      if ($profile_url) {
        $redirect_url = add_query_arg(['kap' => 'linked', 'provider' => rawurlencode($provider)], $profile_url);
      }
    } else {
      $redirect_url = add_query_arg(['kap' => 'linked', 'provider' => rawurlencode($provider)], home_url('/'));
    }
    
    wp_safe_redirect($redirect_url);
    exit;
  }
}

